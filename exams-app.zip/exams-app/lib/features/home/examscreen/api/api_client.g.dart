
part of 'exam_api_client.dart';

import 'package:dio/dio.dart';

import '../data/models/models.dart';
import 'api_client.dart';

class _ExamApiClient implements ExamApiClient {
  _ExamApiClient(this._dio, {this.baseUrl}) {
    baseUrl ??= 'https://exam.elevateegy.com/api/v1/';
  }

  final Dio _dio;
  String? baseUrl;

  @override
  Future<ExamQuestionsResponse> getExamQuestions(
      String examId,
      String token,
      ) async {
    const _extra = <String, dynamic>{};
    final queryParameters = <String, dynamic>{r'exam': examId};
    final _headers = <String, dynamic>{r'token': token};
    _headers.removeWhere((k, v) => v == null);

    final _options = Options(
      method: 'GET',
      headers: _headers,
      extra: _extra,
    );

    final _response = await _dio.request<Map<String, dynamic>>(
      'questions',
      queryParameters: queryParameters,
      options: _options,
    );

    final _value = ExamQuestionsResponse.fromJson(_response.data!);
    return _value;
  }
}

