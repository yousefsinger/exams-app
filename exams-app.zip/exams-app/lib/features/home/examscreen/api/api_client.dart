// lib/features/home/examscreen/api/api_client/exam_api_client.dart

import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import '../../data/models/exam_question_model.dart';
import '../data/models/models.dart';

part 'exam_api_client.g.dart';

@RestApi(baseUrl: 'https://exam.elevateegy.com/api/v1/')
abstract class ExamApiClient {
  factory ExamApiClient(Dio dio, {String baseUrl}) = _ExamApiClient;

  /// GET /questions?exam={examId}
  /// Header: token: <jwt>
  @GET('questions')
  Future<ExamQuestionsResponse> getExamQuestions(
      @Query('exam') String examId,
      @Header('token') String token,
      );
}
